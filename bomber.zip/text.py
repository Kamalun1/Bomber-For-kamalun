import random
colors = 4 random.choice(['\033[1;31m','\033[1;32m','\033[1;33m','\033[1;34m','\033[1;35m','\033[1;36m'])
banner = colors+"""
█▀▀ █▀▄▀█ █▀▀ █▀▀▄ █▀▀█ █░░█ █▀▀ █▀▀█ 
▀▀█ █░▀░█ ▀▀█ █▀▀▄ █▄▄█ █▀▀█ █▀▀ █▄▄▀ 
▀▀▀ ▀░░░▀ ▀▀▀ ▀▀▀░ ▀░░▀ ▀░░▀ ▀▀▀ ▀░▀▀
By Kamalun (Telegram: @Kamalun Vk: vk.com/Kamalun)
"""

cursor = colors+"sms.baher>> "
