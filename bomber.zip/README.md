### Smsbaher-это инструмент для SMS-спама.  Работает на Termux и на Linux.

## Установка
* apt update && apt upgrade;
* pkg install python;
* apt install git;
* git clone https://github.com/Antaskin/smsbaher.git;
* cd smsbaher;
* pip3 install -r requirements.txt;
## Запуск
* python3 smsbaher.py.

ИСТОЧНИК: Telegram: @Kamalun
